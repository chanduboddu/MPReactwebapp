import React from 'react';

const HomeComponent = () => {
  return (
    <div>
      <h1>Hello, I'm a Component!</h1>
    </div>
  );
};

export default HomeComponent;
