import React from 'react';

const ClientComponent = () => {
  return (
   <>
    <div className="main-container clients clients-pg">
      <div className="section-label-wrap">
        <div className="label-divider"></div>
        <h2 className="p--button section-label">our esteemed clients</h2>
        <div className="label-divider"></div>
      </div>
      <h3 className="heading-3 section-heading">Our Happy Customers</h3>
      <div className="clients-page-grid">
        <img src="../../assets/clientimages/cvp-logo.png" width="150" alt="" />
        <img src="../../assets/clientimages/CGI-logo.png" width="80" alt="" />
        <img src="../../assets/clientimages/deloitte-logo-1.png" width="150" alt="" />
        <img src="../../assets/clientimages/WD-Logo-Colored.png" width="150" alt="" />
        <img src="../../assets/clientimages/actionet-logo.png" width="150" alt="" />
        <img src="../../assets/clientimages/pe-logo.png" width="160" alt="" />
        <img src="../../assets/clientimages/VTEK.png" width="150" alt="" />
        <img src="../../assets/clientimages/Savantis_logo.png" width="150" alt="" />
        <img src="../../assets/clientimages/the-aci-group.png" alt="" />
        <img src="../../assets/clientimages/polar.png" width="140" alt="" />
        <img src="../../assets/clientimages/paradigm.png" alt="" />
        <img src="../../assets/clientimages/northrop-grumman.png" width="150" alt="" />
        <img src="../../assets/clientimages/leidos.png" width="150" alt="" />
        <img src="../../assets/clientimages/kforce-inc.png" width="150" alt="" />
        <img src="../../assets/clientimages/issi.png" width="120" alt="" />
        <img src="../../assets/clientimages/mor-software.png" width="150" alt="" />
        <img src="../../assets/clientimages/RandBLogo.png" width="150" alt="" />
        <img src="../../assets/clientimages/ket-systems.png" alt="" />
        <img src="../../assets/clientimages/infolabs.png" width="160" alt="" />
        <img src="../../assets/clientimages/finra.png" width="140" alt="" />
        <img src="../../assets/clientimages/ESIMPLICITY.png" width="170" alt="" />
        <img src="../../assets/clientimages/CareMetx_logo.png" width="150" alt="" />
        <img src="../../assets/clientimages/consortium.png" width="150" alt="" />
        <img src="../../assets/clientimages/Logos-01.png" alt="" />
        <img src="../../assets/clientimages/Logos-02.png" alt="" />
        <img src="../../assets/clientimages/Logos-03.png" alt="" />
        <img src="../../assets/clientimages/Logos-04.png" alt="" />
        <img src="../../assets/clientimages/Logos-05.png" alt="" />
        <img src="../../assets/clientimages/Logos-06.png" alt="" />
        <img src="../../assets/clientimages/Logos-07.png" alt="" />
        <img src="../../assets/clientimages/Logos-08.png" alt="" />
        <img src="../../assets/clientimages/Logos-09.png" alt="" />
        <img src="../../assets/clientimages/Logos-10.png" alt="" />
        <img src="../../assets/clientimages/Logos-11.png" alt="" />
        <img src="../../assets/clientimages/Logos-12.png" alt="" />
        <img src="../../assets/clientimages/Logos-13.png" alt="" />
        <img src="../../assets/clientimages/Logos-14.png" alt="" />
        <img src="../../assets/clientimages/Logos-15.png" alt="" />
        <img src="../../assets/clientimages/Logos-16.png" alt="" />
        <img src="../../assets/clientimages/Logos-17.png" alt="" />
      </div>
    </div>
   </>
  );
};

export default ClientComponent;
