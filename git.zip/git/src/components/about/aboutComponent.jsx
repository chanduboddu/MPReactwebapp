import React from 'react';

const AboutComponent = () => {
  return (
      <>
        <div className="hero-about">
          <div className="main-container hero__content">
            <h1 className="heading-1">About MindPROS</h1>
            <p className="p--regular">
              Professional, dynamic, and self-dedicated team members founded this
              company. Now MindPROS has dedicated its team to diversify in various
              fields. MindPROS has recognized that achievements are only by reason of
              its team spirit and self-confidence that keep in satisfying our customers.
              The main reason for our survival in this competitive field is unbeatable
              Service and Quality that helps us to upgrade our organization, and we
              won’t just deliver products we over-deliver products to our clients, which
              will full fill their desires which is beyond their expectation.
            </p>
          </div>
          <div className="hero-bg about"></div>
        </div>
        <div className="main-container our-values">
          <div className="expertise__title">
            <h2 className="heading-3 expertise">Our Core Values</h2>
            <div className="expertise-line"></div>
          </div>
          <div className="services-grid">
            <div className="grid-filler hide"></div>
            <div id="w-node-d1cd28437a33-f5d49abc" className="services-container">
              <div>
                <div className="fa-normal services-icon"></div>
                <h4 className="heading-5">Dedication</h4>
                <p className="p--regular">To every client’s success.</p>
              </div>
            </div>
            {/* Add more service containers here */}
          </div>
          <div id="values" className="anchor-point"></div>
        </div>
        {/* Add more sections here */}
      </>
  );
};

export default AboutComponent;
