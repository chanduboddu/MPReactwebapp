import React from 'react';

const ProductComponent = () => {
  return (
    <div>
      <h1>Hello, I'm a Component!</h1>
    </div>
  );
};

export default ProductComponent;
