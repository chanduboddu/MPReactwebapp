import React from 'react';

const FooterComponent = () => {
  return (
    <>
      <footer className="footer">
      <div className="main-container footer">
        <div className="footer__main-content">
          <div>
            <a href="index.html" className="w-inline-block w--current">
              <img src="./assets/images/MindPROS-Logo-white.svg" alt="MindPROS Logo" />
            </a>
            <div className="div-block-3">
              <a href="#" className="fa-brands footer__social-links">
                <i className="fa fa-facebook-square" aria-hidden="true"></i>
              </a>
              <a href="#" className="fa-brands footer__social-links">
                <i className="fa fa-twitter-square" aria-hidden="true"></i>
              </a>
              <a href="#" className="fa-brands footer__social-links">
                <i className="fa fa-linkedin-square" aria-hidden="true"></i>
              </a>
            </div>
          </div>
          <div className="footer__links-grid">
            <div>
              <h6 className="p--button footer__titles">COMPANY</h6>
              <ul className="w-list-unstyled">
                <li className="footer__list-items">
                  <a href="about-us.html" className="footer__links">About Us</a>
                </li>
                <li className="footer__list-items">
                  <a href="/about-us.html#values" className="footer__links">Core Values</a>
                </li>
                <li className="footer__list-items">
                  <a href="careers.html" className="footer__links">Careers</a>
                </li>
                <li className="footer__list-items">
                  <a href="clients.html" className="footer__links">Clients</a>
                </li>
                <li className="footer__list-items">
                  <a href="contact-us.html" className="footer__links">Contact Us</a>
                </li>
              </ul>
            </div>
            <div>
              <h6 className="p--button footer__titles">learn more</h6>
              <ul className="w-list-unstyled">
                <li className="footer__list-items">
                  <a href="products.html" className="footer__links">Products</a>
                </li>
                <li className="footer__list-items">
                  <a href="services.html" className="footer__links">Services</a>
                </li>
                <li className="footer__list-items">
                  <a href="/technology.html" className="footer__links">Technology</a>
                </li>
                <li className="footer__list-items">
                  <a href="/training.html" className="footer__links">Training</a>
                </li>
                <li className="footer__list-items">
                  <a href="/about-us.html#certifications" className="footer__links">Certifications</a>
                </li>
              </ul>
            </div>
            <div id="w-node-c8363b293a72-3b293a3e">
            <h6 className="p--button footer__titles">contact</h6>
            <div className="p--regular address">
              21 Governors Ct, Suite 180, Baltimore, MD 21244. USA
            </div>
            <ul className="w-list-unstyled">
              <li className="footer__list-items contact">
                <div>
                  <span className="fa-solid space-left-10"
                    ><i className="fa fa-phone" aria-hidden="true"></i></span
                  ><a href="tel:4107755999" className="footer__links"
                    >(410) 775-5999</a
                  >
                </div>
              </li>
              <li className="footer__list-items contact">
                <div>
                  <span className="fa-solid space-left-10"
                    ><i className="fa fa-print" aria-hidden="true"></i></span
                  ><a href="#" className="footer__links">(410) 775-5998</a>
                </div>
              </li>
              <li className="footer__list-items contact">
                <div>
                  <span className="fa-solid space-left-10"
                    ><i className="fa fa-envelope" aria-hidden="true"></i></span
                  ><a
                    href="./assets/cdn-cgi/l/email-protection#4f262129200f2226212b623f3d203c612c2022"
                    className="footer__links"
                    ><span
                      className="__cf_email__"
                      data-cfemail="b6dfd8d0d9f6dbdfd8d29bc6c4d9c598d5d9db"
                      >[email&#160;protected]</span
                    ></a
                  >
                </div>
              </li>
            </ul>
          </div>
        </div>
      </div>
      <div className="footer__copyright">
        <div>Copyright © 2018 MindPROS, Inc. All Rights Reserved.</div>
        <div className="div-block">
          <a href="privacy-policies.html" className="footer__links">Privacy Policy</a
          ><a href="security.html" className="footer__links">Security</a>
        </div>
      </div>
      </div>
      </footer>
    </>
  );
};

export default FooterComponent;
