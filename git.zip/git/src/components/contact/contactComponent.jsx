import React from 'react';

const ContactComponent = () => {
  return (
  <>
     <div className="hero-products">
      <div className="main-container hero__content">
        <h1 className="heading-1">Get in Touch with Us</h1>
      </div>
      <div className="hero-bg contact"></div>
    </div>
    <div className="main-container">
      <div className="contact-info-group">
        <div className="contact-item">
          <div className="contact-label-group mp-gradient">
            <div className="contact-label-title">
              <span className="contact-label-icon">
                <i className="fa fa-phone" aria-hidden="true"></i>
              </span>
              CALL
            </div>
          </div>
          <div className="heading-4 contact-info">(410) 775-5999</div>
        </div>
        <div className="contact-item">
          <div className="contact-label-group mp-gradient">
            <div className="contact-label-title">
              <span className="contact-label-icon">
                <i className="fa fa-envelope" aria-hidden="true"></i>
              </span>
              EMAIL
            </div>
          </div>
          <div className="heading-4 contact-info">
            <a href="/cdn-cgi/l/email-protection" className="__cf_email__" data-cfemail="c7aea9a1a887aaaea9a3eab7b5a8b4e9a4a8aa">[email&nbsp;protected]</a>
          </div>
        </div>
        <div className="contact-item">
          <div className="contact-label-group mp-gradient">
            <div className="contact-label-title">
              <span className="contact-label-icon">
                <i className="fa fa-print" aria-hidden="true"></i>
              </span>
              FAX
            </div>
          </div>
          <div className="heading-4 contact-info">(410) 775-5998</div>
        </div>
      </div>
      <div className="div-block-14">
        <div className="div-block-15">
          <div className="w-embed w-iframe">
          </div>
        </div>
        </div>
        </div>
  </>
  );
};

export default ContactComponent;
