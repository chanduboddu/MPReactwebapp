import React from 'react';

const CarrerComponent = () => {
  return (
   <>
     <div className="hero-about">
        <div className="main-container hero__content">
          <h1 className="heading-1">Careers</h1>
        </div>
        <div className="hero-bg about"></div>
      </div>
      <div className="main-container our-values">
        <div className="expertise__title">
          <h2 className="heading-3 expertise">BECOME PART OF A WINNING TEAM</h2>
          <div className="expertise-line"></div>
        </div>
        <p className="p--regular">
          MindPROS believes that a business can achieve its economic objectives and
          contribute to the well being of employees, clients and community. We hire
          the best and brightest technology professionals and offer them competitive
          salaries and benefits.<br /><br />
          We offer ongoing technical training to our employees. We also offer
          non-technical training to help them improve the quality of their lives. It
          teaches life-improving concepts such as meditation and positive thinking. We
          believe that a healthy mind, body and spirit are the foundation for
          happiness and prosperity. Our goal is to have long-term, mutually beneficial
          relationships with our employees. MindPROS is an Equal Opportunity Employer.
          So, if you are looking for a growing professional consulting company that
          believes in trust, openness, caring and fairness, MindPROS is your company!
          If you are interested in pursuing a career with MindPROS, please review the
          existing job opportunities. If your profile does not match any existing
          position, you can also mail us your resume to
          <a
            href="/cdn-cgi/l/email-protection#f2989d9081b2bf9b9c96a2a0bda1dc919d9f"
            target="_top"
            ><span
              className="__cf_email__"
              data-cfemail="aac2d8eae7c3c4cefaf8e5f984c9c5c7"
              >[email&#160;protected]</span
            ></a
          >
        </p>
        <br /><br />
        <h4>Referral Bonus:</h4>
        <p className="p--regular">
          MindPROS, Inc. offers an employee referral program to encourage employees to
          recommend qualified candidates. Our referral program provides employees with
          a referral bonus for successful hires made based upon an employee’s
          recommendation. If a recommended candidate is hired and completes 90 days of
          service, the employee who provided the referral will be entitled to a bonus
          of $500.00 (five hundred dollars only). All referred candidates will be
          considered and evaluated based on experience and qualifications, and they
          will be subject to the same pre-employment standards as all other
          candidates. Questions regarding this policy should be directed to Human
          Resources.
        </p>
        <div className="hr-line"></div>
        <div className="job-list">
          <div className="careers-title">Systems Engineer</div>
          <p className="p--regular">
            Baltimore, MD & various unanticipated client sites throughout U.S. Under
            the guidance of the Lead Systems Engineer, participate in business
            requirements analysis utilizing the Software Development Life Cycle
            (SDLC). Help develop feature-rich web user interfaces collaboratively to
            manage and monitor the client’s extensive ecosystem of applications,
            services, and hosts. Develop utilities to drive innovation and streamline
            workflows. Ensure solutions are aligned with business and IT strategies
            and comply with the organization’s architectural standards. Requires
            minimum of BS or equiv. in CS, CIS, IT-related Engineering,
            Information/Data, or a related field, with three (3) yrs of prior
            progressive professional experience in the position offered or related.
            Mail resumes to: MindPROS, Inc., Job SE, 21 Governors Ct, Suite 180,
            Baltimore, MD 21244.
          </p>
          {/* Add more job listings here */}
        </div>
        <div id="values" className="anchor-point"></div>
      </div>
   </>
  );
};

export default CarrerComponent;
