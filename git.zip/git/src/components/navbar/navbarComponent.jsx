import React from 'react';
import { Link } from 'react-router-dom';
const NavbarComponent = () => {
  return (
  <>
    <header className="header">
      <div className="header__links-wrap">
        <div className="main-container header-contact">
          <div className="header__contact">
            <a href="tel:4107755999" className="header-contact-link">
              <span className="fa-solid space-left-10">
                <i className="fa fa-phone" aria-hidden="true"></i>
              </span>
              (410) 775-5999
            </a>
            <a 
              href="./assets/cdn-cgi/l/email-protection#50393e363f103d393e347d20223f237e333f3d"
              className="header-contact-link"
            >
              <span className="fa-solid space-left-10">
                <i className="fa fa-envelope" aria-hidden="true"></i>
              </span>
              <span className="__cf_email__" data-cfemail="b0d9ded6dff0ddd9ded49dc0c2dfc39ed3dfdd">
                [email&#160;protected]
              </span>
            </a>
          </div>
          <div className="header__other-links">
            <Link to="/careers" className="header-contact-link">Careers</Link>
            <a
              href="http://3.218.140.109:4200"
              target="_blank"
              rel="noopener noreferrer"
              className="header-contact-link"
            >
              Employee Area
            </a>
            <div>
              <a href="#" className="header-contact-link fa-brands header-social-links">
                <i className="fa fa-facebook-square" aria-hidden="true"></i>
              </a>
              <a href="#" className="header-contact-link fa-brands header-social-links">
                <i className="fa fa-twitter-square" aria-hidden="true"></i>
              </a>
              <a href="#" className="header-contact-link fa-brands header-social-links">
                <i className="fa fa-linkedin-square" aria-hidden="true"></i>
              </a>
            </div>
          </div>
        </div>
      </div>
      <div className="main-container header__nav-wrap">
        <a href="index.html" className="w-inline-block w--current">
          <img src="./assets/images/MindPROS-Logo.svg" alt="MindPROS Logo" className="header-logo" />
        </a>
        <div
          data-collapse="medium"
          data-animation="default"
          data-duration="500"
          data-easing="ease-out-quint"
          data-easing2="ease-out-quint"
          className="navbar w-nav"
        >
          <div className="w-container">
            <nav role="navigation" className="nav-menu w-nav-menu">
              <Link to="/" className="nav-link w-nav-link">home</Link>
              <Link to="/about" className="nav-link w-nav-link">about</Link>
              <Link to="/services" className="nav-link w-nav-link">services</Link>
              <Link to="/products" className="nav-link w-nav-link">products</Link>
              <Link to="/client" className="nav-link w-nav-link">clients</Link>
              <Link to="/contact" className="nav-link w-nav-link">contact</Link>
            </nav>
            <div className="menu-button w-nav-button">
              <div className="p--button">MENU</div>
            </div>
          </div>
        </div>
      </div>
    </header>

  </>
  );
};

export default NavbarComponent;
