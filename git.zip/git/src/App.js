import './App.css';
import { BrowserRouter as Router,Routes, Route } from 'react-router-dom';
import NavbarComponent from './components/navbar/navbarComponent';
import AboutComponent from './components/about/aboutComponent';
import CarrerComponent from './components/careers/carrerComponent';

function App() {
  return (
    <div className="App">
     <h1>app</h1>
     <Router>
     <Routes>
        <Route path="/" exact  element={<NavbarComponent/>} />
        <Route path="/about"  element={<AboutComponent/>} />
        <Route path="/contact"  element={<CarrerComponent/>} />
      </Routes>
    </Router>
    </div>
  );
}

export default App;
